<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Link to the external style.css file -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">

    <%@ include file="header.jsp" %>
</head>

<body style="background-color: white;">

    <!-- Main content wrapper -->
    <div id="page-content-wrapper" class="container-fluid">
        <!-- Section with heading -->
        <div class="row justify-content-center mt-5">
            <div class="col-12 text-center">
                <h2 class="page-title" style="color: black;">Trip Summary</h2>
            </div>
        </div>

        <!-- Button Row -->
        <div class="row mb-4 justify-content-between">
            <!-- Region Dropdown -->
            <div class="col-12 col-md-4 d-flex justify-content-start">
                <select class="form-select" id="regionDropdown" style="width: 180px;">
                    <option selected>Choose Region</option>
                    <option value="gp">GP</option>
                    <option value="cpt">CPT</option>
                    <option value="linehaul">LINEHAUL</option>
                </select>
            </div>

            <!-- Date Picker and Refresh Button -->
            <div class="col-12 col-md-8 d-flex justify-content-end">
                <!-- Date Picker -->
                <input type="date" class="form-control me-2" id="tripDate" min="2025-02-15" max="2025-02-18" value="2025-02-15" style="width: 180px">
                
                <!-- Refresh Button -->
                <button class="btn btn-blue d-flex align-items-center">Refresh Data</button>
            </div>
        </div>

        <!-- Table -->
        <div class="row grid-area">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-bordered" style="border: 2px solid black;">
                        <thead>
                            <tr>
                                <th>Client</th>
                                <th>Collection</th>
                                <th>Delivery</th>
                                <th>Loads/Split</th>
                                <th>SGL/DBL</th>
                                <th>Driver Truck Reg</th>
                                <th>Client Bookings</th>
                                <th>POD Ref No</th>
                                <th>KJE Delivery No</th>
                                <th>CHEP No</th>
                                <th>Load Con</th>
                                <th>Status</th>
                                <th>Note</th>
                                <th>KMs Travelled</th>
                                <th>Time Collected</th>
                                <th>Time Delivered</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Client A</td>
                                <td>2025-02-01 08:00:00</td>
                                <td>2025-02-01 15:30:00</td>
                                <td>2</td>
                                <td>SGL</td>
                                <td>TRK123</td>
                                <td>Booking1</td>
                                <td>POD123</td>
                                <td>KJE123</td>
                                <td>CHEP123</td>
                                <td>Load 1</td>
                                <td>In Progress</td>
                                <td>Some notes here</td>
                                <td>120</td>
                                <td>2025-02-01 08:05:00</td>
                                <td>2025-02-01 15:35:00</td>
                            </tr>
                            <tr>
                                <td>Client B</td>
                                <td>2025-02-02 09:00:00</td>
                                <td>2025-02-02 16:00:00</td>
                                <td>3</td>
                                <td>DBL</td>
                                <td>TRK456</td>
                                <td>Booking2</td>
                                <td>POD456</td>
                                <td>KJE456</td>
                                <td>CHEP456</td>
                                <td>Load 2</td>
                                <td>Completed</td>
                                <td>Additional notes here</td>
                                <td>200</td>
                                <td>2025-02-02 09:05:00</td>
                                <td>2025-02-02 16:05:00</td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

</body>

</html>
