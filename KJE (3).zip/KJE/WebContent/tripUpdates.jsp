<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Link to the external style.css file -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">

    <%@ include file="header.jsp" %>
</head>

<body style="background-color: white;">

    <!-- Main content wrapper -->
    <div id="page-content-wrapper" class="container-fluid">
        <!-- Section with heading -->
        <div class="row justify-content-center mt-5">
            <div class="col-12 text-center">
                <h2 class="page-title" style="color: black;">Trip Updates</h2>
            </div>
        </div>

        <!-- Button Row -->
        <div class="row mb-4 justify-content-between">
            <!-- Region Dropdown -->
            <div class="col-12 col-md-4 d-flex justify-content-start">
                <select class="form-select" id="regionDropdown" style="width: 180px;">
                    <option selected>Choose Region</option>
                    <option value="gp">GP</option>
                    <option value="cpt">CPT</option>
                    <option value="linehaul">LINEHAUL</option>
                </select>
            </div>

            <!-- Date Picker and Refresh Button -->
            <div class="col-12 col-md-8 d-flex justify-content-end">
                <!-- Date Picker -->
                <input type="date" class="form-control me-2" id="tripDate" min="2025-02-15" max="2025-02-18" value="2025-02-15" style="width: 180px">
                
                <!-- Refresh Button -->
                <button class="btn btn-blue d-flex align-items-center">Refresh Data</button>
            </div>
        </div>

        <!-- Table -->
        <div class="row grid-area">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-bordered" style="border: 2px solid black;">
                        <thead>
                            <tr>
                                <th>Client</th>
                                <th>Collection</th>
                                <th>Delivery</th>
                                <th>Loads/Split</th>
                                <th>SGL/DBL</th>
                                <th>Driver Truck Reg</th>
                                <th>Collection Odometer</th>
                                <th>Delivery Odometer</th>
                                <th>Client Bookings</th>
                                <th>POD Ref No</th>
                                <th>KJE Delivery No</th>
                                <th>CHEP No</th>
                                <th>Load Con</th>
                                <th>Status</th>
                                <th>Note</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Client A</td>
                                <td></td>
                                <td></td>
                                <td>2</td>
                                <td>SGL</td>
                                <td>TRK123</td>
                                 <td>125000</td>
                                  <td>185000</td>
                                <td>Booking1</td>
                                <td>POD123</td>
                                <td>KJE123</td>
                                <td>CHEP123</td>
                                <td>Load 1</td>
                                <td>In Progress</td>
                                <td>Some notes here</td>
                                <td>
                                    <button class="btn btn-collection" data-bs-toggle="modal" data-bs-target="#tripCollectionModal">Collection</button>
                                    <button class="btn btn-delivery" data-bs-toggle="modal" data-bs-target="#tripDeliveryModal">Delivery</button>
                                    <button class="btn btn-invoice" data-bs-toggle="modal" data-bs-target="#tripInvoiceModal">Invoice</button>
                                </td>
                            </tr>
                            <tr>
                                <td>Client B</td>
                                <td></td>
                                <td></td>
                                <td>3</td>
                                <td>DBL</td>
                                <td>TRK456</td>
                                <td>Booking2</td>
                                <td>POD456</td>
                                <td>KJE456</td>
                                <td>CHEP456</td>
                                <td>Load 2</td>
                                <td>Completed</td>
                                <td>Additional notes here</td>
                                <td>
                                    <button class="btn btn-collection" data-bs-toggle="modal" data-bs-target="#tripCollectionModal">Collection</button>
                                    <button class="btn btn-delivery" data-bs-toggle="modal" data-bs-target="#tripDeliveryModal">Delivery</button>
                                    <button class="btn btn-invoice" data-bs-toggle="modal" data-bs-target="#tripInvoiceModal">Invoice</button>
                                </td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Trip Collection Modal -->
    <div class="modal fade" id="tripCollectionModal" tabindex="-1" aria-labelledby="tripCollectionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tripCollectionModalLabel">Trip Collection</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="mb-3">
                            <label for="clientName" class="form-label">Client</label>
                            <input type="text" class="form-control" id="clientName" value="Client A" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="tripDate" class="form-label">Date</label>
                            <input type="date" class="form-control" id="tripDate" value="2025-02-01" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="odometer" class="form-label">Odometer</label>
                            <input type="text" class="form-control" id="odometer" placeholder="Enter Odometer" required>
                        </div>
                        <div class="mb-3">
                            <label for="loadSplit" class="form-label">Load Split</label>
                            <input type="text" class="form-control" id="loadSplit" value="2" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="driverTruck" class="form-label">Driver Truck Reg</label>
                            <input type="text" class="form-control" id="driverTruck" value="TRK123" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="pod" class="form-label">POD</label>
                            <input type="text" class="form-control" id="pod" placeholder="Enter POD number" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Collected</button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Trip Delivery Modal -->
    <div class="modal fade" id="tripDeliveryModal" tabindex="-1" aria-labelledby="tripDeliveryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tripDeliveryModalLabel">Trip Delivery</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="mb-3">
                            <label for="clientName" class="form-label">Client</label>
                            <input type="text" class="form-control" id="clientName" value="Client A" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="tripDate" class="form-label">Date</label>
                            <input type="date" class="form-control" id="tripDate" value="2025-02-01" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="odometer" class="form-label">Odometer</label>
                            <input type="text" class="form-control" id="odometer" placeholder="Enter Odometer" required>
                        </div>
                        <div class="mb-3">
                            <label for="loadSplit" class="form-label">Load Split</label>
                            <input type="text" class="form-control" id="loadSplit" value="2" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="driverTruck" class="form-label">Driver Truck Reg</label>
                            <input type="text" class="form-control" id="driverTruck" value="TRK123" disabled>
                        </div>
                        <div class="mb-3">
                            <label for="pod" class="form-label">POD</label>
                            <input type="text" class="form-control" id="pod" placeholder="Enter POD number" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Delivered</button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Trip Invoice Modal -->
    <div class="modal fade" id="tripInvoiceModal" tabindex="-1" aria-labelledby="tripInvoiceModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tripInvoiceModalLabel">Trip Invoice</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Invoice Form Content -->
                        <p>Invoice content goes here</p>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-purple" data-bs-dismiss="modal">Generate Invoice</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

</body>

</html>
