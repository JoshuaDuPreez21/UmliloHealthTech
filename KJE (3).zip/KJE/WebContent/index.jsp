<%@ include file="/header.jsp" %>

<body>
    
        <!-- Main Content Section -->
    <div class="main-content">
        <div class="container">
            <h2>Welcome to My Web App</h2>
            <p>This is the body of the page with the light grey background.</p>
        </div>
    </div>

</body>

 <!-- Footer Section -->
 <footer>
     <p>Footer Text - Dark Grey Background</p>
 </footer>

 <script>
 
 	function hello(){
 		alert("hello");
 	}
 	
 </script>