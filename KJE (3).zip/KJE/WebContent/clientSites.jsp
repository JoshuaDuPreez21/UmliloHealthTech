<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Link to the external style.css file -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/styles.css">
    
    <%@ include file="header.jsp" %>
</head>

<body style="background-color: white;">

    <!-- Main content wrapper -->
    <div id="page-content-wrapper" class="container-fluid">
        <!-- Section with heading (No description as per request) -->
        <div class="row justify-content-center mt-5">
            <div class="col-12 text-center">
                <h2 class="page-title" style="color: black;">Client Sites</h2>
            </div>
        </div>

        <!-- Button Row -->
        <div class="row mb-4 justify-content-between">
            <!-- Button Section (Left aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-start">
                <button class="btn btn-blue me-2" data-bs-toggle="modal" data-bs-target="#newSiteModal">New Site</button>
            </div>

            <!-- Refresh Data Button (Right aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-end">
                <button class="btn btn-blue">Refresh Data</button>
            </div>
        </div>

        <!-- Placeholder Grid Area (for future content) -->
        <div class="row grid-area">
            <div class="col-12">
                <!-- Sample Grid Structure (use a table or grid system as needed) -->
                <div class="table-responsive">
                    <table class="table table-bordered" style="border: 2px solid black;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Region</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Site 1</td>
                                <td>123 Site Address, City, Country</td>
                                <td>GP</td>
                                <td>
                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editSiteModal" onclick="populateEditModal('Site 1', '123 Site Address, City, Country', 'GP')">Edit</button>
                                </td>
                            </tr>
                            <tr>
                                <td>Site 2</td>
                                <td>456 Another Address, City, Country</td>
                                <td>CPT</td>
                                <td>
                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editSiteModal" onclick="populateEditModal('Site 2', '456 Another Address, City, Country', 'CPT')">Edit</button>
                                </td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- New Site Modal -->
    <div class="modal fade" id="newSiteModal" tabindex="-1" aria-labelledby="newSiteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newSiteModalLabel">Create New Site</h5>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Name Input -->
                        <div class="mb-3">
                            <label for="siteName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="siteName" placeholder="Enter Site Name">
                        </div>

                        <!-- Address Input -->
                        <div class="mb-3">
                            <label for="siteAddress" class="form-label">Address</label>
                            <input type="text" class="form-control" id="siteAddress" placeholder="Enter Address">
                        </div>

                        <!-- Region Dropdown -->
                        <div class="mb-3">
                            <label for="siteRegion" class="form-label">Region</label>
                            <select class="form-select" id="siteRegion">
                                <option value="gp">GP</option>
                                <option value="cpt">CPT</option>
                                <option value="linehaul">LINEHAUL</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Site Modal -->
    <div class="modal fade" id="editSiteModal" tabindex="-1" aria-labelledby="editSiteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editSiteModalLabel">Edit Site</h5>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Name Input -->
                        <div class="mb-3">
                            <label for="editSiteName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="editSiteName">
                        </div>

                        <!-- Address Input -->
                        <div class="mb-3">
                            <label for="editSiteAddress" class="form-label">Address</label>
                            <input type="text" class="form-control" id="editSiteAddress">
                        </div>

                        <!-- Region Dropdown -->
                        <div class="mb-3">
                            <label for="editSiteRegion" class="form-label">Region</label>
                            <select class="form-select" id="editSiteRegion">
                                <option value="gp">GP</option>
                                <option value="cpt">CPT</option>
                                <option value="linehaul">LINEHAUL</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <script>
        function populateEditModal(name, address, region) {
            document.getElementById('editSiteName').value = name;
            document.getElementById('editSiteAddress').value = address;
            document.getElementById('editSiteRegion').value = region;
        }
    </script>

</body>

</html>
