/**
 * 
 */

 /**
 * A generic function to make a POST request to the given URL with the provided data.
 * 
 * @param {string} url - The URL for the API endpoint.
 * @param {object} data - The data to be sent to the server.
 * @returns {Promise<any>} - A promise that resolves to the response from the server.
 * 
 * 
 */
 
const baseURL = window.location.origin + "/KJE/rest/";

async function postWebService(url, data) {
    try {
        // Send the request using fetch with the POST method and headers
        let response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json', // Set the content type to JSON
            },
            body: JSON.stringify(data), // Convert the JavaScript object to JSON string
        });

        // Check if the response is ok (status code is 200-299)
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        // Parse the response JSON and return it
        let responseData = await response.json();
        return responseData;

    } catch (error) {
        console.error('Error in postWebService:', error);
        return null;  // or you can throw the error, based on your use case
    }
}
