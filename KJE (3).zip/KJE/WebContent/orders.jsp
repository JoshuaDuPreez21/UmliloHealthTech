<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">


<head>
    <!-- Link to the external style.css file -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/styles.css">
    
    <%@ include file="header.jsp" %>
</head>

<body style="background-color: white;">

    <!-- Main content wrapper -->
    <div id="page-content-wrapper" class="container-fluid">
        <!-- Section with heading (No description as per request) -->
        <div class="row justify-content-center mt-5">
            <div class="col-12 text-center">
                <h2 class="page-title" style="color: black;">Orders</h2>
            </div>
        </div>

        <!-- Button Row -->
        <div class="row mb-4 justify-content-between">
            <!-- Button Section (Left aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-start">
                <button class="btn btn-blue me-2" data-bs-toggle="modal" data-bs-target="#newOrderModal">New Order</button>
                <!-- <button class="btn btn-blue me-2">Edit Order</button> -->
            </div>

            <!-- Refresh Data Button (Right aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-end">
                <button class="btn btn-blue">Refresh Data</button>
            </div>
        </div>

        <!-- Placeholder Grid Area (for future content) -->
        <div class="row grid-area">
            <div class="col-12">
                <!-- Sample Grid Structure (use a table or grid system as needed) -->
                <div class="table-responsive">
                    <table class="table table-bordered" style="border: 2px solid black;">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Client</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>001</td>
                                <td>Client A</td>
                                <td>2025-02-01</td>
                                <td>Pending</td>
                                <td>
                                    <button class="btn btn-sm btn-warning">Edit</button>
                                </td>
                            </tr>
                            <tr>
                                <td>002</td>
                                <td>Client B</td>
                                <td>2025-02-05</td>
                                <td>Completed</td>
                                <td>
                                    <button class="btn btn-sm btn-warning">Edit</button>
                                </td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<!-- New Order Modal -->
<div class="modal fade" id="newOrderModal" tabindex="-1" aria-labelledby="newOrderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newOrderModalLabel">Create New Order</h5>
            </div>
            <div class="modal-body">
                <form>
                    <!-- Sales Order Input -->
                    <div class="mb-3">
                        <label for="salesOrder" class="form-label">Sales Order</label>
                        <input type="text" class="form-control" id="salesOrder" placeholder="Enter Sales Order">
                    </div>

                    <!-- Sales Order Date (Date Picker) -->
                    <div class="mb-3">
                        <label for="orderDate" class="form-label">Sales Order Date</label>
                        <input type="date" class="form-control" id="orderDate">
                    </div>

                    <!-- Client Dropdown -->
                    <div class="mb-3">
                        <label for="clientSelect" class="form-label">Client</label>
                        <select class="form-select" id="clientSelect">
                            <option selected>Choose Client</option>
                            <option value="1">Client A</option>
                            <option value="2">Client B</option>
                            <option value="3">Client C</option>
                        </select>
                    </div>
                    
                    <!-- Load Split Dropdown -->
                    <div class="mb-3">
                        <label for="loadSplit" class="form-label">Load Split</label>
                        <select class="form-select" id="loadSplit">
                            <option selected>Choose Load Split</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>

                    <!-- Collection and Delivery Dropdowns (Initially Visible) -->
                    <div id="collectionDeliveryContainer">
                        <div class="mb-3">
                            <label for="collectionSelect" class="form-label">Collection</label>
                            <select class="form-select" id="collectionSelect">
                                <option selected>Choose Collection</option>
                                <option value="4">Collection 1</option>
                                <option value="5">Collection 2</option>
                                <option value="6">Collection 3</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="deliverySelect" class="form-label">Delivery</label>
                            <select class="form-select" id="deliverySelect">
                                <option selected>Choose Delivery</option>
                                <option value="1">Delivery 1</option>
                                <option value="2">Delivery 2</option>
                                <option value="3">Delivery 3</option>
                            </select>
                        </div>
                    </div>

                    <!-- Dynamic Load Split Dropdowns (Initially Hidden) -->
                    <div id="dynamicLoadDiv" style="display: none;">
                        <!-- Dynamically generated content will appear here -->
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" onclick="newOrder()">Save</button>
            </div>
        </div>
    </div>
</div>
    
    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="${pageContext.request.contextPath}/serviceHelper.js"></script>
   
    
    
 <script>
    // Get references to the relevant elements
    const loadSplitDropdown = document.getElementById('loadSplit');
    const collectionDeliveryContainer = document.getElementById('collectionDeliveryContainer');
    const dynamicLoadDiv = document.getElementById('dynamicLoadDiv');

    // Listen for changes in the Load Split dropdown
    loadSplitDropdown.addEventListener('change', function() {
        const loadSplitValue = parseInt(loadSplitDropdown.value);

        // Reset the dynamic content before applying changes
        dynamicLoadDiv.innerHTML = '';
        
        // If Load Split is 1, show the default Collection and Delivery dropdowns
        if (loadSplitValue === 1) {
            collectionDeliveryContainer.style.display = 'block';
            dynamicLoadDiv.style.display = 'none';
        } else {
            // Hide the default Collection and Delivery dropdowns
            collectionDeliveryContainer.style.display = 'none';

            // Show the dynamic collection and delivery dropdowns based on the Load Split value
            dynamicLoadDiv.style.display = 'block';
            for (let i = 1; i <= loadSplitValue; i++) {
                const row = document.createElement('div');
                row.classList.add('mb-3');

                // Create Collection Label
                const collectionLabel = document.createElement('label');
                collectionLabel.classList.add('form-label');
                collectionLabel.setAttribute('for', `collectionSelect${i}`);
                collectionLabel.textContent = `Collection ${i}`;
                row.appendChild(collectionLabel);

                // Create Collection Dropdown
                const collectionSelect = document.createElement('select');
                collectionSelect.classList.add('form-select');
                collectionSelect.id = `collectionSelect${i}`;
                collectionSelect.innerHTML = `
                    <option selected>Choose Collection ${i}</option>
                    <option value="collection1">Collection 1</option>
                    <option value="collection2">Collection 2</option>
                    <option value="collection3">Collection 3</option>
                `;
                row.appendChild(collectionSelect);

                // Create Delivery Label
                const deliveryLabel = document.createElement('label');
                deliveryLabel.classList.add('form-label');
                deliveryLabel.setAttribute('for', `deliverySelect${i}`);
                deliveryLabel.textContent = `Delivery ${i}`;
                row.appendChild(deliveryLabel);

                // Create Delivery Dropdown
                const deliverySelect = document.createElement('select');
                deliverySelect.classList.add('form-select');
                deliverySelect.id = `deliverySelect${i}`;
                deliverySelect.innerHTML = `
                    <option selected>Choose Delivery ${i}</option>
                    <option value="delivery1">Delivery 1</option>
                    <option value="delivery2">Delivery 2</option>
                    <option value="delivery3">Delivery 3</option>
                `;
                row.appendChild(deliverySelect);

                // Add the line separator (<hr>)
                const hr = document.createElement('hr');
                hr.classList.add('my-4'); // Optional: adds margin to separate the line a bit
                row.appendChild(hr);

                // Append the row to the dynamic load div
                dynamicLoadDiv.appendChild(row);
            }
        }
    });
    
    async function newOrder() {
        // Get the values of the static fields (Sales Order, Order Date, Client, etc.)
        let salesOrder = $("#salesOrder").val();
        let orderDate = $("#orderDate").val();
        let client = $("#clientSelect").val();
        let loadSplit = $("#loadSplit").val();
        
        // Initialize an array to hold the JSON objects for the collection and delivery pairs
        let collectionDeliveryArray = [];
        
        // If loadSplit is 1, get the values from the original dropdowns
        if (loadSplit === "1") {
            let collectionSiteId = $("#collectionSelect").val();
            let deliverySiteId = $("#deliverySelect").val();
            
            // Create a JSON object for the pair and push it into the array
            collectionDeliveryArray.push({
                collectionSiteId: collectionSiteId,
                deliverySiteId: deliverySiteId
            });
        } else {
            // For multiple loads (2 or more), loop through each dynamic pair of dropdowns
            for (let i = 1; i <= loadSplit; i++) {
                let collectionSiteId = $(`#collectionSelect${i}`).val();
                let deliverySiteId = $(`#deliverySelect${i}`).val();
                
                // Create a JSON object for each pair and push it into the array
                collectionDeliveryArray.push({
                    collectionSiteId: collectionSiteId,
                    deliverySiteId: deliverySiteId
                });
            }
        }

        // Now you can combine all the data (salesOrder, orderDate, client, etc.) into an object
        let newOrderData = {
            salesOrder: salesOrder,
            salesOrderDate: orderDate,
            idClient: client,
            orderDetails: collectionDeliveryArray,
            loads : loadSplit
        };

        // Log the resulting object to verify (you can send this data to the server or use it as needed)
        console.log(newOrderData);
        
        let url = baseURL +  "order/newOrder";
		let response = await postWebService(url,newOrderData);
        
		if(typeof response != 'undefined' && response != null){
			if(typeof response.error != 'undefined' && response.error != null && response.error){
				toastr.error("The order could not be created! Please try again or contact support");
			}else{
				toastr.success('A new order has been created!');
			}
		}
    }

</script>
</body>

</html>

