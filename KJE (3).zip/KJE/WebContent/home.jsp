<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">

<%@ include file="header.jsp" %>

<body>
    <!-- Sidebar -->
    <div id="sidebar">
        <h3>KJE Logistics</h3>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="clients.jsp">CLIENTS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="drivers.jsp">DRIVERS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="clientSites.jsp">CLIENT SITES</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="orders.jsp">ORDERS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="tripUpdates.jsp">TRIP UPDATES</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="trips.jsp">TRIPS</a>
            </li>
        </ul>
    </div>

    <!-- Page Content Area -->
    <div id="page-content-wrapper">
        <div class="container-fluid">
            <!-- Section with heading and description -->
            <div class="row justify-content-center mt-3">
                <div class="col-12 text-center">
                    <h2 class="page-title">Clients</h2>
                    <p class="page-description">Welcome to the clients page. Here you can manage and view client details.</p>
                </div>
            </div>

            
        </div>
    </div>

    <!-- Footer -->
    <footer>
    </footer>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
