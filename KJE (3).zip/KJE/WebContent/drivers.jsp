<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/styles.css">
    
    <%@ include file="header.jsp" %>
</head>

<body style="background-color: white;">

    <div id="page-content-wrapper" class="container-fluid">
        <!-- Section with Heading for Drivers -->
        <div class="row justify-content-center mt-5">
            <div class="col-12 text-center">
                <h2 class="page-title" style="color: black;">Drivers</h2>
            </div>
        </div>

        <!-- Button and Filter Row -->
        <div class="row mb-4 justify-content-between">
            <div class="col-12 col-md-6 d-flex justify-content-start">
                <button class="btn btn-blue me-2" data-bs-toggle="modal" data-bs-target="#newDriverModal">New Driver</button>
            </div>
            <div class="col-12 col-md-6 d-flex justify-content-end">
                <select class="form-select" id="regionDropdown" style="width: 180px;">
                    <option selected>Choose Region</option>
                    <option value="gp">GP</option>
                    <option value="cpt">CPT</option>
                    <option value="linehaul">LINEHAUL</option>
                </select>
                <button class="btn btn-blue ms-2">Refresh Data</button>
            </div>
        </div>

        <!-- Driver Grid -->
        <div class="row grid-area">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-bordered" style="border: 2px solid black;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Surname</th>
                                <th>Date of Birth</th>
                                <th>ID Number</th>
                                <th>Cellphone Number</th>
                                <th>Alternative Number</th>
                                <th>Email Address</th>
                                <th>Licence Code</th>
                                <th>Licence Expiry</th>
                                <th>Nationality</th>
                                <th>Region</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>John</td>
                                <td>Doe</td>
                                <td>1990-01-01</td>
                                <td>1234567890</td>
                                <td>0812345678</td>
                                <td>0823456789</td>
                                <td>johndoe@email.com</td>
                                <td>A12345</td>
                                <td>2025-01-01</td>
                                <td>South African</td>
                                <td>GP</td>
                                <td>
                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editDriverModal" onclick="populateEditModal('John', 'Doe', '1990-01-01', '1234567890', '0812345678', '0823456789', 'johndoe@email.com', 'A12345', '2025-01-01', 'South African', 'GP')">Edit</button>
                                </td>
                            </tr>
                            <!-- More rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- New Driver Modal -->
    <div class="modal fade" id="newDriverModal" tabindex="-1" aria-labelledby="newDriverModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newDriverModalLabel">Add New Driver</h5>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Name Input -->
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" placeholder="Enter Name">
                        </div>
                        <!-- Surname Input -->
                        <div class="mb-3">
                            <label for="surname" class="form-label">Surname</label>
                            <input type="text" class="form-control" id="surname" placeholder="Enter Surname">
                        </div>
                        <!-- Date of Birth Input -->
                        <div class="mb-3">
                            <label for="dob" class="form-label">Date of Birth</label>
                            <input type="date" class="form-control" id="dob">
                        </div>
                        <!-- ID Number Input -->
                        <div class="mb-3">
                            <label for="idNumber" class="form-label">ID Number</label>
                            <input type="text" class="form-control" id="idNumber" placeholder="Enter ID Number">
                        </div>
                        <!-- Cellphone Number Input -->
                        <div class="mb-3">
                            <label for="cellphone" class="form-label">Cellphone Number</label>
                            <input type="text" class="form-control" id="cellphone" placeholder="Enter Cellphone Number">
                        </div>
                        <!-- Alternative Number Input -->
                        <div class="mb-3">
                            <label for="altNumber" class="form-label">Alternative Number</label>
                            <input type="text" class="form-control" id="altNumber" placeholder="Enter Alternative Number">
                        </div>
                        <!-- Email Input -->
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter Email Address">
                        </div>
                        <!-- Licence Code Input -->
                        <div class="mb-3">
                            <label for="licenceCode" class="form-label">Licence Code</label>
                            <input type="text" class="form-control" id="licenceCode" placeholder="Enter Licence Code">
                        </div>
                        <!-- Licence Expiry Input -->
                        <div class="mb-3">
                            <label for="licenceExpiry" class="form-label">Licence Expiry</label>
                            <input type="date" class="form-control" id="licenceExpiry">
                        </div>
                        <!-- Nationality Input -->
                        <div class="mb-3">
                            <label for="nationality" class="form-label">Nationality</label>
                            <input type="text" class="form-control" id="nationality" placeholder="Enter Nationality">
                        </div>
                        <!-- Region Dropdown -->
                        <div class="mb-3">
                            <label for="region" class="form-label">Region</label>
                            <select class="form-select" id="region">
                                <option value="gp">GP</option>
                                <option value="cpt">CPT</option>
                                <option value="linehaul">LINEHAUL</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Driver Modal -->
    <div class="modal fade" id="editDriverModal" tabindex="-1" aria-labelledby="editDriverModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDriverModalLabel">Edit Driver</h5>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Name Input -->
                        <div class="mb-3">
                            <label for="editName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="editName">
                        </div>
                        <!-- Surname Input -->
                        <div class="mb-3">
                            <label for="editSurname" class="form-label">Surname</label>
                            <input type="text" class="form-control" id="editSurname">
                        </div>
                        <!-- Date of Birth Input -->
                        <div class="mb-3">
                            <label for="editDob" class="form-label">Date of Birth</label>
                            <input type="date" class="form-control" id="editDob">
                        </div>
                        <!-- ID Number Input -->
                        <div class="mb-3">
                            <label for="editIdNumber" class="form-label">ID Number</label>
                            <input type="text" class="form-control" id="editIdNumber">
                        </div>
                        <!-- Cellphone Number Input -->
                        <div class="mb-3">
                            <label for="editCellphone" class="form-label">Cellphone Number</label>
                            <input type="text" class="form-control" id="editCellphone">
                        </div>
                        <!-- Alternative Number Input -->
                        <div class="mb-3">
                            <label for="editAltNumber" class="form-label">Alternative Number</label>
                            <input type="text" class="form-control" id="editAltNumber">
                        </div>
                        <!-- Email Input -->
                        <div class="mb-3">
                            <label for="editEmail" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="editEmail">
                        </div>
                        <!-- Licence Code Input -->
                        <div class="mb-3">
                            <label for="editLicenceCode" class="form-label">Licence Code</label>
                            <input type="text" class="form-control" id="editLicenceCode">
                        </div>
                        <!-- Licence Expiry Input -->
                        <div class="mb-3">
                            <label for="editLicenceExpiry" class="form-label">Licence Expiry</label>
                            <input type="date" class="form-control" id="editLicenceExpiry">
                        </div>
                        <!-- Nationality Input -->
                        <div class="mb-3">
                            <label for="editNationality" class="form-label">Nationality</label>
                            <input type="text" class="form-control" id="editNationality">
                        </div>
                        <!-- Region Dropdown -->
                        <div class="mb-3">
                            <label for="editRegion" class="form-label">Region</label>
                            <select class="form-select" id="editRegion">
                                <option value="gp">GP</option>
                                <option value="cpt">CPT</option>
                                <option value="linehaul">LINEHAUL</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <script>
        function populateEditModal(name, surname, dob, id, cellphone, altNumber, email, licenceCode, licenceExpiry, nationality, region) {
            document.getElementById('editName').value = name;
            document.getElementById('editSurname').value = surname;
            document.getElementById('editDob').value = dob;
            document.getElementById('editIdNumber').value = id;
            document.getElementById('editCellphone').value = cellphone;
            document.getElementById('editAltNumber').value = altNumber;
            document.getElementById('editEmail').value = email;
            document.getElementById('editLicenceCode').value = licenceCode;
            document.getElementById('editLicenceExpiry').value = licenceExpiry;
            document.getElementById('editNationality').value = nationality;
            document.getElementById('editRegion').value = region;
        }
    </script>
</body>

</html>
