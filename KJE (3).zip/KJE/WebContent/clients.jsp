<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Link to the external style.css file -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/styles.css">
    
    <%@ include file="header.jsp" %>
</head>

<body style="background-color: white;">

    <!-- Main content wrapper -->
    <div id="page-content-wrapper" class="container-fluid">
        <!-- Section with heading -->
        <div class="row justify-content-center mt-5">
            <div class="col-12 text-center">
                <h2 class="page-title" style="color: black;">Clients</h2>
            </div>
        </div>

        <!-- Button Row -->
        <div class="row mb-4 justify-content-between">
            <!-- Button Section (Left aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-start">
                <button class="btn btn-blue me-2" data-bs-toggle="modal" data-bs-target="#newClientModal">New Client</button>
            </div>

            <!-- Refresh Data Button (Right aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-end">
                <button class="btn btn-blue">Refresh Data</button>
            </div>
        </div>

        <!-- Placeholder Grid Area (for future content) -->
        <div class="row grid-area">
            <div class="col-12">
                <!-- Sample Grid Structure (use a table or grid system as needed) -->
                <div class="table-responsive">
                    <table class="table table-bordered" style="border: 2px solid black;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Client Bookings</th>
                                <th>Client Contact</th>
                                <th>Email Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Client 1</td>
                                <td>Booking 123</td>
                                <td>John Doe</td>
                                <td>john@example.com</td>
                                <td>
                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editClientModal" onclick="populateEditModal('Client 1', 'Booking 123', 'John Doe', 'john@example.com')">Edit</button>
                                </td>
                            </tr>
                            <tr>
                                <td>Client 2</td>
                                <td>Booking 456</td>
                                <td>Jane Smith</td>
                                <td>jane@example.com</td>
                                <td>
                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editClientModal" onclick="populateEditModal('Client 2', 'Booking 456', 'Jane Smith', 'jane@example.com')">Edit</button>
                                </td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- New Client Modal -->
    <div class="modal fade" id="newClientModal" tabindex="-1" aria-labelledby="newClientModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newClientModalLabel">Create New Client</h5>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Name Input -->
                        <div class="mb-3">
                            <label for="clientName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="clientName" placeholder="Enter Client Name">
                        </div>

                        <!-- Client Bookings Input -->
                        <div class="mb-3">
                            <label for="clientBookings" class="form-label">Client Bookings</label>
                            <input type="text" class="form-control" id="clientBookings" placeholder="Enter Client Bookings">
                        </div>

                        <!-- Client Contact Input -->
                        <div class="mb-3">
                            <label for="clientContact" class="form-label">Client Contact</label>
                            <input type="text" class="form-control" id="clientContact" placeholder="Enter Client Contact">
                        </div>

                        <!-- Email Address Input -->
                        <div class="mb-3">
                            <label for="clientEmail" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="clientEmail" placeholder="Enter Email Address">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Client Modal -->
    <div class="modal fade" id="editClientModal" tabindex="-1" aria-labelledby="editClientModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editClientModalLabel">Edit Client</h5>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Name Input -->
                        <div class="mb-3">
                            <label for="editClientName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="editClientName">
                        </div>

                        <!-- Client Bookings Input -->
                        <div class="mb-3">
                            <label for="editClientBookings" class="form-label">Client Bookings</label>
                            <input type="text" class="form-control" id="editClientBookings">
                        </div>

                        <!-- Client Contact Input -->
                        <div class="mb-3">
                            <label for="editClientContact" class="form-label">Client Contact</label>
                            <input type="text" class="form-control" id="editClientContact">
                        </div>

                        <!-- Email Address Input -->
                        <div class="mb-3">
                            <label for="editClientEmail" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="editClientEmail">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <script>
        function populateEditModal(name, bookings, contact, email) {
            document.getElementById('editClientName').value = name;
            document.getElementById('editClientBookings').value = bookings;
            document.getElementById('editClientContact').value = contact;
            document.getElementById('editClientEmail').value = email;
        }
    </script>

</body>

</html>
