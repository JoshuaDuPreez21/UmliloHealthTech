package services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import DAO.OrderDAO;
import co.za.kje.Objects.Order;

@Path("order")
public class orderService {

	@Path("newOrder")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response newOrder(String body) throws SQLException {
		JSONObject toReturn = new JSONObject();
		
		try {
			JSONObject jsonObject = new JSONObject(body);
			
			String salesOrder = null;
			String salesOrderDate = null;
			Long idClient = null;
			JSONArray orderDetails = null;
			Long loads = null;

			if (jsonObject.has("salesOrder") && !jsonObject.isNull("salesOrder")) {
			    salesOrder = jsonObject.getString("salesOrder");
			}

			if (jsonObject.has("salesOrderDate") && !jsonObject.isNull("salesOrderDate")) {
			    salesOrderDate = jsonObject.getString("salesOrderDate");
			}

			if (jsonObject.has("idClient") && !jsonObject.isNull("idClient")) {
				idClient = jsonObject.getLong("idClient");
			}

			if (jsonObject.has("orderDetails") && !jsonObject.isNull("orderDetails")) {
			    orderDetails = jsonObject.getJSONArray("orderDetails");
			}

			if (jsonObject.has("loads") && !jsonObject.isNull("loads")) {
			    loads = jsonObject.getLong("loads");
			}

			// Now, collectionSiteIds and deliverySiteIds contain the corresponding IDs

			Order order = new Order();
			order.setIdClient(idClient);
			order.setLoadSplit(loads);
			order.setSalesOrder(salesOrder);
			order.setSalesOrderDate(salesOrderDate);
			order.setOrderDetails(orderDetails.toString());
			
			OrderDAO orderDAO = new OrderDAO();
			Boolean saved = orderDAO.saveOrder(order);
			if(!saved) {
				toReturn.put("error",true);
			}else {
				toReturn.put("orderId",order.getId());
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return Response.status(200).entity(toReturn.toString()).build();
	}
}
