package co.za.kje.services;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;


@Path("/hello")
public class testService {
	   
    @GET
    @Path("/")
    public String sayHello() {
    	try {
             // Define the URL for the POST request
             String url = "https://graph.facebook.com/v13.0/514032831792051/messages";
             
             // Create the HTTP POST request
             HttpPost postRequest = new HttpPost(url);
             
             // Set the authorization header
             postRequest.setHeader("Authorization", "Bearer EAAP4ci5GDZA8BOzfFN43yvtaFL78sRxdBRttNBZBPecV7XP60jcRu8EZCcJlXcXvbakIX94xSEUm12IutLA6G44wrb6WbkXt99i4Vt9rXxhqnyNRsfKvyTsxSGfSXEHIAPTDikmZAFZCj3SWhOEwUB9aSBy6zjw7Ft640o3IzpCvXQhL6ZAXTQRCHD75mcot882LigTZAnsyZBc7sSrB0o9Nx6EZB8ZCf4ag90ePfi7aZBcLqBhXJlug1gZD");
             postRequest.setHeader("Content-Type", "application/json");

             // Set the request body (JSON data)
             String jsonBody = "{ \"messaging_product\": \"whatsapp\", " +
                     "\"recipient_type\": \"individual\", " +
                     "\"to\": \"27618067750\", " +
                     "\"type\": \"text\", " +
                     "\"text\": { \"preview_url\": false, " +
                     "\"body\": \"This is an example of a text message\" } }";
             // Set the body of the request
             StringEntity entity = new StringEntity(jsonBody);
             postRequest.setEntity(entity);
             
             // Create the HttpClient and execute the request
             try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
                 HttpResponse response = httpClient.execute(postRequest);
                 
                 // Extract and print the response body
                 String responseString = EntityUtils.toString(response.getEntity());
                 System.out.println(responseString);
             }
         } catch (Exception e) {
             e.printStackTrace();
         }
    	 
    	 return "Success";
    }
}


