package co.za.kje.Objects;

public class Order {
	
	public Long id;
	public String salesOrder;
	public String salesOrderDate;
	public Long idClient;
	public Long loadSplit;
	public String orderDetails; // this will be a jsonArray
	public String createdTime;
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSalesOrder() {
		return salesOrder;
	}
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	public String getSalesOrderDate() {
		return salesOrderDate;
	}
	public void setSalesOrderDate(String salesOrderDate) {
		this.salesOrderDate = salesOrderDate;
	}
	public Long getIdClient() {
		return idClient;
	}
	public void setIdClient(Long idClient) {
		this.idClient = idClient;
	}
	public Long getLoadSplit() {
		return loadSplit;
	}
	public void setLoadSplit(Long loadSplit) {
		this.loadSplit = loadSplit;
	}
	public String getOrderDetails() {
		return orderDetails;
	}
	public void setOrderDetails(String orderDetails) {
		this.orderDetails = orderDetails;
	}
	public String getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}
}
