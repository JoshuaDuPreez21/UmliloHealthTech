package DAO;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseConnection {

    public static Connection getConnection() throws SQLException {
        try {
            // Create an InitialContext to look up the DataSource
            Context context = new InitialContext();
            
            // Look up the DataSource using JNDI
            DataSource dataSource = (DataSource) context.lookup("java:/comp/env/jdbc/MySQLDataSource");

            // Return a connection from the DataSource
            return dataSource.getConnection();

        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Unable to get DB connection", e);
        }
    }
}
