package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import co.za.kje.Objects.Order;

public class OrderDAO {

    /**
     * Save the Order to the database
     * 
     * @param order The Order object to be saved
     * @return boolean True if the order was successfully saved, false otherwise
     * @throws SQLException 
     */
	public boolean saveOrder(Order order) throws SQLException {
	    // Get the database connection
	    Connection connection = DatabaseConnection.getConnection();

	    // Check if the connection is valid (you can specify a timeout in seconds)
	    if (connection == null || !connection.isValid(2)) {
	        System.out.println("Invalid connection! Cannot proceed with saving the order.");
	        return false; // Return false if the connection is not valid
	    }

	    String sql = "INSERT INTO `order` (salesOrder, salesOrderDate, idClient, loadSplit, orderDetails) VALUES (?, ?, ?, ?, ?)";

	    try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
	        // Set the values of the prepared statement
	        stmt.setString(1, order.getSalesOrder());
	        stmt.setString(2, order.getSalesOrderDate());
	        stmt.setLong(3, order.getIdClient());
	        stmt.setLong(4, order.getLoadSplit());
	        stmt.setString(5, order.getOrderDetails());

	        // Execute the update
	        int rowsAffected = stmt.executeUpdate();

	        // If the order was inserted successfully, return true
	        if (rowsAffected > 0) {
	            // Optionally, get the generated keys (like the order ID) after insertion
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace(); // Log the exception
	    } finally {
	        // Ensure the connection is closed to avoid resource leaks
	        if (connection != null && !connection.isClosed()) {
	            connection.close();
	        }
	    }

	    return false; // Return false if the order couldn't be saved
	}

}
