<!-- header.jsp -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KJE Logistics</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/css/bootstrap.min.css">
    
    <!-- Custom CSS for background and colors -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/styles.css">
    
    <!-- jQuery (needed for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Custom Sidebar Styles -->
    <style>
        /* KJE LOGISTICS font style */
        #sidebar h3 {
            text-transform: uppercase;
            font-family: 'Roboto', sans-serif;
            font-size: 1.5rem;
            font-weight: bold;
            color: #A8CF45; /* KJE Green */
            margin-top: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Styling for sidebar links */
        #sidebar .nav-link {
            text-align: center; /* Center the text for each page name */
            font-size: 1.1rem;
            font-weight: normal;
            color: #fff; /* White color for text */
        }

        /* Styling for sidebar logout button */
        #logout-btn {
            background-color: transparent;
            border: 2px solid #A8CF45; /* KJE Green */
            color: #A8CF45; /* KJE Green text */
            border-radius: 5px; /* Slightly rounded corners */
            padding: 10px 20px; /* Half the previous height and added 20px padding on left and right */
            font-weight: bold;
            width: calc(100% - 40px); /* Makes it 40px smaller than sidebar width for padding */
            position: absolute;
            bottom: 20px; /* Keep button at the bottom of the sidebar */
            left: 20px; /* Make sure button is aligned with the padding */
        }

        /* Styling for sidebar image (eagle image) */
        #sidebar .eagle-image {
            display: block;
            width: 100%;
            margin: 5px auto; /* Center the eagle image */
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div id="sidebar" class="collapsed">
        <!-- Sidebar content (collapsed version will show only the toggle icon) -->
        <button id="sidebar-toggle" class="sidebar-toggle-btn">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div id="sidebar-content" class="sidebar-content">
           <!--  <h3>KJE LOGISTICS</h3> -->
			<div style="padding: 5px">
            	  <!-- Add Eagle Image above the Logout Button -->
            	<img src="${pageContext.request.contextPath}/KJE_logo.png" alt="Eagle" class="eagle-image">
            </div>
           
            <!-- Sidebar Navigation -->
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="orders.jsp">ORDERS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tripUpdates.jsp">TRIP UPDATES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="trips.jsp">TRIP SUMMARY</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="drivers.jsp">DRIVERS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="clients.jsp">CLIENTS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="clientSites.jsp">CLIENT SITES</a>
                </li>
            </ul>
            
            
            
           

            <!-- Logout Button -->
            <button id="logout-btn" class="btn btn-logout">
                Logout
            </button>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JavaScript for Sidebar Toggle -->
    <script>
        document.getElementById("sidebar-toggle").addEventListener("click", function() {
            var sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("collapsed");
        });
    </script>
</body>
