<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">


<head>
    <!-- Link to the external style.css file -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/styles.css">
    
    <%@ include file="header.jsp" %>
</head>

<body style="background-color: white;">

    <!-- Main content wrapper -->
    <div id="page-content-wrapper" class="container-fluid">
        <!-- Section with heading (No description as per request) -->
        <div class="row justify-content-center mt-5">
            <div class="col-12 text-center">
                <h2 class="page-title" style="color: black;">Orders</h2>
            </div>
        </div>

        <!-- Button Row -->
        <div class="row mb-4 justify-content-between">
            <!-- Button Section (Left aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-start">
                <button class="btn btn-blue me-2" data-bs-toggle="modal" data-bs-target="#newOrderModal">New Order</button>
                <!-- <button class="btn btn-blue me-2">Edit Order</button> -->
            </div>

            <!-- Refresh Data Button (Right aligned) -->
            <div class="col-12 col-md-6 d-flex justify-content-end">
                <button class="btn btn-blue">Refresh Data</button>
            </div>
        </div>

        <!-- Placeholder Grid Area (for future content) -->
        <div class="row grid-area">
            <div class="col-12">
                <!-- Sample Grid Structure (use a table or grid system as needed) -->
                <div class="table-responsive">
                    <table class="table table-bordered" style="border: 2px solid black;">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Client</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>001</td>
                                <td>Client A</td>
                                <td>2025-02-01</td>
                                <td>Pending</td>
                                <td>
                                    <button class="btn btn-sm btn-warning">Edit</button>
                                </td>
                            </tr>
                            <tr>
                                <td>002</td>
                                <td>Client B</td>
                                <td>2025-02-05</td>
                                <td>Completed</td>
                                <td>
                                    <button class="btn btn-sm btn-warning">Edit</button>
                                </td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- New Order Modal -->
    <div class="modal fade" id="newOrderModal" tabindex="-1" aria-labelledby="newOrderModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newOrderModalLabel">Create New Order</h5>
                </div>
                <div class="modal-body">
                    <form>
                        <!-- Sales Order Input -->
                        <div class="mb-3">
                            <label for="salesOrder" class="form-label">Sales Order</label>
                            <input type="text" class="form-control" id="salesOrder" placeholder="Enter Sales Order">
                        </div>

                        <!-- Sales Order Date (Date Picker) -->
                        <div class="mb-3">
                            <label for="orderDate" class="form-label">Sales Order Date</label>
                            <input type="date" class="form-control" id="orderDate">
                        </div>

                        <!-- Client Dropdown -->
                        <div class="mb-3">
                            <label for="clientSelect" class="form-label">Client</label>
                            <select class="form-select" id="clientSelect">
                                <option selected>Choose Client</option>
                                <option value="client1">Client A</option>
                                <option value="client2">Client B</option>
                                <option value="client3">Client C</option>
                            </select>
                        </div>

                        <!-- Collection Dropdown -->
                        <div class="mb-3">
                            <label for="collectionSelect" class="form-label">Collection</label>
                            <select class="form-select" id="collectionSelect">
                                <option selected>Choose Collection</option>
                                <option value="collection1">Collection 1</option>
                                <option value="collection2">Collection 2</option>
                                <option value="collection3">Collection 3</option>
                            </select>
                        </div>

                        <!-- Delivery Dropdown -->
                        <div class="mb-3">
                            <label for="deliverySelect" class="form-label">Delivery</label>
                            <select class="form-select" id="deliverySelect">
                                <option selected>Choose Delivery</option>
                                <option value="delivery1">Delivery 1</option>
                                <option value="delivery2">Delivery 2</option>
                                <option value="delivery3">Delivery 3</option>
                            </select>
                        </div>

                        <!-- Load Split Dropdown -->
                        <div class="mb-3">
                            <label for="loadSplit" class="form-label">Load Split</label>
                            <select class="form-select" id="loadSplit">
                                <option selected>Choose Load Split</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                	<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="${pageContext.request.contextPath}/webjars/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
